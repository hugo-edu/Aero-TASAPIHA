package aeroport;

public class Passager extends Personne {
}
