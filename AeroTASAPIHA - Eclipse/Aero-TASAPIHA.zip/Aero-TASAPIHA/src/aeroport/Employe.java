package aeroport;

public class Employe extends Personne {
}
