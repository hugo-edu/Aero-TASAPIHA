package aeroport;

public interface GestionAvion {
    
    public abstract void embarquer(Passager passager);
    public abstract void debarquer();

}
