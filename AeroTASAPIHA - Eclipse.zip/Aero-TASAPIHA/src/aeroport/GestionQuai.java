package aeroport;

public interface GestionQuai {
    
    public abstract void atterrissage(Avion avion);
    public abstract void decollage();

}
