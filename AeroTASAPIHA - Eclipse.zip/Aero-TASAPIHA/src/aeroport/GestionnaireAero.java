package aeroport;

public class GestionnaireAero {
    
    private Aeroport aeroport;

    public Aeroport getAeroport() {      
        return this.aeroport;
    }

    public void setAeroport(Aeroport aeroport) {
        this.aeroport = aeroport;
    }

}
